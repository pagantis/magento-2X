<?php

namespace Clearpay\Clearpay\Test\Install;

use Clearpay\Clearpay\Test\Common\AbstractMg21Selenium;
use Facebook\WebDriver\WebDriverExpectedCondition;
use Facebook\WebDriver\WebDriverBy;

/**
 * Class clearpayMgInstallTest
 * @package Clearpay\Test\Install
 *
 */
class clearpayMgInstallTest extends AbstractMg21Selenium
{
    /**
     * testClearpayMg21InstallTest
     * @group magento-install
     * @throws \Exception
     */
    public function testClearpayMg21InstallTest()
    {
        $this->loginToBackOffice();
        $this->getclearpayBackOffice();
        $this->configureclearpay();
        $this->quit();
    }

    /**
     * testClearpayMg21ConfigureTest
     * @group magento-configure
     */
    public function testClearpayMg21ConfigureTest()
    {
        $this->loginToBackOffice();
        $this->configureclearpay();
        $this->quit();
    }

    /**
     * @require getclearpayBackOffice
     *
     * @throws \Exception
     */
    private function configureclearpay()
    {
        $verify = WebDriverBy::id('payment_us_clearpay_clearpay_merchant_id');
        $condition = WebDriverExpectedCondition::visibilityOfElementLocated($verify);
        $this->webDriver->wait()->until($condition);
        $this->assertTrue((bool) $condition, "PR5");

        $verify = WebDriverBy::id('payment_us_clearpay_clearpay_merchant_key');
        $condition = WebDriverExpectedCondition::visibilityOfElementLocated($verify);
        $this->webDriver->wait()->until($condition);
        $this->assertTrue((bool) $condition, "PR5");

        $activeSelect = $this->findById('payment_us_clearpay_active');
        $activeOptions = $activeSelect->findElements(WebDriverBy::xpath('option'));
        foreach ($activeOptions as $activeOption) {
            if ($activeOption->getText() == 'Yes') {
                $activeOption->click();
                break;
            }
        }

        $this->findById('payment_us_clearpay_clearpay_public_key')->clear()->sendKeys($this->configuration['publicKey']);
        $this->findById('payment_us_clearpay_clearpay_private_key')->clear()->sendKeys($this->configuration['secretKey']);

        $this->findById('config-edit-form')->submit();

        $validatorSearch = WebDriverBy::className('message-success');
        $actualString = $this->webDriver->findElement($validatorSearch)->getText();
        $compareString = (strstr($actualString, 'You saved the configuration')) === false ? false : true;
        $this->assertTrue($compareString, $actualString);

        $enabledModule = $this->findByCss("select#payment_us_clearpay_active > option[selected]");
        $this->assertEquals($enabledModule->getText(), 'Yes', 'PR6');

        $verify = WebDriverBy::id('payment_us_clearpay_active');
        $condition = WebDriverExpectedCondition::visibilityOfElementLocated($verify);
        $this->webDriver->wait()->until($condition);
        $this->assertTrue((bool) $condition, "PR7");
    }
}
