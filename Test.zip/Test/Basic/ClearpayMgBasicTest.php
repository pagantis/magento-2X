<?php

namespace Clearpay\Clearpay\Test\Basic;

use Clearpay\Clearpay\Test\Common\AbstractMg21Selenium;
use Facebook\WebDriver\WebDriverExpectedCondition;

/**
 * Class clearpayMgBasicTest
 * @package Clearpay\Test\Basic
 *
 * @group magento-basic
 */
class clearpayMgBasicTest extends AbstractMg21Selenium
{
    /**
     * String
     */
    const TITLE = 'Home';

    /**
     * String
     */
    const BACKOFFICE_TITLE = 'Admin';

    /**
     * testMagentoOpen
    */
    public function testclearpayMg21BasicTest()
    {
        try {
            $this->webDriver->get($this->configuration['magentoUrl']);
            $condition = WebDriverExpectedCondition::titleContains(self::TITLE);
            echo $this->webDriver->getPageSource();
            $this->webDriver->wait()->until($condition);
            $this->assertTrue((bool) $condition, $this->configuration['magentoUrl']);
            $this->quit();
        } catch (\Exception $e) {
            echo $this->webDriver->getPageSource();
        }
    }

    /**
     * testBackofficeOpen
     */
    public function testBackofficeOpen()
    {
        $this->webDriver->get($this->configuration['magentoUrl'].self::BACKOFFICE_FOLDER);
        $condition = WebDriverExpectedCondition::titleContains(self::BACKOFFICE_TITLE);
        $this->webDriver->wait()->until($condition);
        $this->assertTrue((bool) $condition);
        $this->quit();
    }
}
