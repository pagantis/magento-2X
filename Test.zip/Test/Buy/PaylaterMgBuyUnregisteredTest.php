<?php

namespace Pagantis\Pagantis\Test\Buy;

use Pagantis\Pagantis\Test\Common\AbstractMg21Selenium;


/**
 * Class pagantisMgBuyUnregisteredTest
 *
 * @group magento-buy-unregistered
 */
class pagantisMgBuyUnregisteredTest extends AbstractMg21Selenium
{
    /**
     * @throws \Exception
     */
    public function testBuy()
    {
        $this->goToProduct();
        $this->configureProduct();
        $this->checkProductPage();
        $this->goToCheckout();
        $this->prepareCheckout();
        $this->preparePaymentMethod();
        $this->verifypagantis();
        $this->verifyOrder();
        $this->quit();
    }

    /**
     * @throws \Exception
     */
    public function testMGtotalAmount()
    {
        $this->assertEquals(900, $this->getMGTotalAmount(9));
        $this->assertEquals(99900, $this->getMGTotalAmount(999));
        $this->assertEquals(999900, $this->getMGTotalAmount(9999));
        //9
        $this->assertEquals(900, $this->getMGTotalAmount(9.0));
        $this->assertEquals(900, $this->getMGTotalAmount(9.00));
        $this->assertEquals(99900, $this->getMGTotalAmount(9.99));
        $this->assertEquals(90900, $this->getMGTotalAmount(9.09));
        $this->assertEquals(99000, $this->getMGTotalAmount(9.90));
        //999
        $this->assertEquals(99900, $this->getMGTotalAmount(999.0));
        $this->assertEquals(99900, $this->getMGTotalAmount(999.00));
        $this->assertEquals(99999, $this->getMGTotalAmount(999.99));
        $this->assertEquals(99909, $this->getMGTotalAmount(999.09));
        $this->assertEquals(99990, $this->getMGTotalAmount(999.90));
        $this->quit();
    }




    /**
     * Float to INT
     *
     * @param null $amount
     * @return string
     */
    public function getMGTotalAmount($amount = null)
    {
        $amount = (float)$amount;
        return intval(100 * $amount);
    }
}