<?php

namespace Clearpay\Clearpay\Test\Register;

use Clearpay\Clearpay\Test\Common\AbstractMg21Selenium;

/**
 * Class clearpayMgInstallTest
 * @package Clearpay\Test\Register
 *
 * @group magento-register
 */
class clearpayMgRegisterTest extends AbstractMg21Selenium
{
    /**
     * @require configureclearpay
     *
     * @throws \Exception
     */
    public function testRegisterAndLogin()
    {
        $this->createAccount();
        $this->logoutFromFrontend();
        $this->loginToFrontend();
        $this->logoutFromFrontend();
        $this->quit();
    }
}
